@echo off
start "" "%~dp0java\bin\javaw.exe" -jar "%~dp0app\agendamento.jar"
