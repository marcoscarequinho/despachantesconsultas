@echo off
rem Agendamento Detran RJ - Despachantes Consultas
cd /d "%~dp0"
start "Agendamento Detran" java\bin\javaw.exe -cp app\agendamento.jar br.com.despachantesconsultas.agendamento.Main
